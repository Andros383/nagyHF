#ifndef GAME_PIECE_ROTATIONS_H
#define GAME_PIECE_ROTATIONS_H

#include "menu_selector.h"

void rotate_cw(GameState *game_state, int *upkick);
void rotate_ccw(GameState *game_state, int *upkick);
#endif