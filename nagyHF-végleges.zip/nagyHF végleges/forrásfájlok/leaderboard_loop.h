#ifndef LEADERBOARD_LOOP_H
#define LEADERBOARD_LOOP_H

#include <SDL2/SDL.h>
#include <SDL2/SDL2_gfxPrimitives.h>
#include <SDL2/SDL_ttf.h>

int leaderboard_loop(SDL_Renderer *renderer, TTF_Font *font);

#endif